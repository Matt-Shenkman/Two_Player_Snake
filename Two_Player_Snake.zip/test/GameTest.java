import static org.junit.Assert.fail;
import org.junit.Test;

/** 
 *  You can use this file (and others) to test your
 *  implementation.
 */

public class GameTest {

    @Test
    public void test() {
        fail();
    }

}
